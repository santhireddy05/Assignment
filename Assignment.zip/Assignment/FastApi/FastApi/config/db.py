from sqlalchemy import create_engine, MetaData

engine = create_engine("sqlite:///applications")
#engine = create_engine("mysql+pymysql://root@localhost:3036/test")
meta = MetaData()
conn = engine.connect()